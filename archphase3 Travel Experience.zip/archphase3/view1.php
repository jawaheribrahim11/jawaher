


<?php 
	
	$var = mysqli_connect('localhost', 'root', '', 'tex');
	function display()
	{
		global $var;
		$query ="SELECT * FROM `journey`";
		$run = mysqli_query($var, $query);

		if ($run == TRUE) {
			?>
			<table border="5" width="50%">
				<?php
			
			while ( $data = mysqli_fetch_assoc($run)) {
				?>
				<tr>
					<td> <?php echo $data['id'];
							   echo "<br>"; ?>
							
					</td>					
					<td> <?php echo $data['name'];
							   echo "<br>"; ?>
							
					</td>					
					<td> <?php echo $data['de'];
							   echo "<br>"; ?>
							
					</td>					
							
				</tr>
				<?php
			}
			?>
			</table>
			<?php

		} else {
			echo "Error!";
		}
	}
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>School-Management</title>
 </head>
 <body>
 		<?php  
 			display();
 		?>
 </body>
 </html>