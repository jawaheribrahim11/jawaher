<?php
	$id=$_GET['id'];
	$query=mysqli_query($conn,"select * from `registration` where userid='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Basic MySQLi Commands</title>
</head>
<body>
	<h2>Edit</h2>
	<form method="POST" action="edit.php?id=<?php echo $id; ?>">
		<label>Name:</label><input type="text" value="<?php echo $row['username']; ?>" name="username">
		<label>Email:</label><input type="email" value="<?php echo $row['email']; ?>" name="email">
		<input type="submit" name="submit">
		<a href="userslist.php">Back</a>
	</form>
</body>
</html>