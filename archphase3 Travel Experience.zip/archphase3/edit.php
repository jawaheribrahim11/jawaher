<?php
	include('db_connection.php');
	$id=$_GET['id'];
 
	$name=$_POST['usernamme'];
	$email=$_POST['email'];
 
	mysqli_query($conn,"update `registration` set username='$name', email='$email' where id='$id'");
	header('location:update.php');
?>
