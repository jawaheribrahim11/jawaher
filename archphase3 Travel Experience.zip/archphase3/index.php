<?php  
		$name = $_POST ['name'];	//from index.php(html form) name
		$de = $_POST ['de'];	//from index.php(html form) name


		$conn = mysqli_connect('localhost', 'root', '', 'tex');

		$query = "INSERT INTO `journey`(`name`, `de`) VALUES ('$name','$de')";

		$run = mysqli_query($conn, $query);

		if ($run == TRUE){
			echo "This is insert into Database table";
		}
		else 
			echo "error!";	
		
?>