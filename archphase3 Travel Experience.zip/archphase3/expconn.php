<?php
		$nametex = $_POST['nametex'];
        $image_url=$_POST['image_url'];		

	// Database connection
	$conn = new mysqli('localhost','root','','users');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into images(nametex, image_url ) values(?, ? )");
		$stmt->bind_param("ss", $nametex,$image_url);
		$execval = $stmt->execute();
		echo $execval;
		echo "submission successfully...";
		$stmt->close();
		$conn->close();
		header("Location: Home.html");
	}
?>