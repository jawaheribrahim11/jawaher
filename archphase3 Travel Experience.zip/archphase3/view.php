<?php
 
// Username is root
$user = 'root';
$password = '';
 
// Database name is geeksforgeeks
$database = 'users';
 
// Server is localhost with
// port number 3306
$servername='localhost';
$mysqli = new mysqli($servername, $user,
                $password, $database);
 
// Checking for connections
if ($mysqli->connect_error) {
    die('Connect Error (' .
    $mysqli->connect_errno . ') '.
    $mysqli->connect_error);
}
 
// SQL query to select data from database
$sql = " SELECT * FROM images ORDER BY id ASC ";
$result = $mysqli->query($sql);
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Users journey</title>

    <style>
        
        button{
  margin-left:50px ;
  color: #5e94a5;
  padding: 9px 25px;
  background-color: rgb(38, 56, 60);
  border: none;
  border-radius: 50px;
  cursor: pointer;
   transition: all0.3s ease 0s;

}  button:hover{
  background-color: rgb(91, 169, 188);
}
        
        .b{
            padding: 20px;
            margin: 20px;
            display: inline-block;
            justify-content: center;
        }
        table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
      border-color: while;

}
     th, td {
  padding-top: 10px;
  padding-bottom: 20px;
  padding-left: 30px;
  padding-right: 40px;
     
        }
        tr{

            border-radius:20px ;

            border: 20;
            margin: 20px;
            color: whitesmoke;
            background-color: #5e94a5;
            border-color: black;
            padding: 10px;

        
        }
        th{
            border: 1;
            margin: 20px;

            color: white;
        background-color:#5e94a5;
        padding: 20px;
        border-color: black;
        padding: 10px;

        }
        td{
            margin: 20px;
padding: 10px;
            text-align: center;
            justify-content: center;
            color: whitesmoke;
            border: 1;

        }
        .buttonT{
width: 5px;  

font-size: 10px;  
height: 10px
;

}
    </style>
</head>
<header>
  <img class="logo" style="width:10%;height:10%" src="1.jpeg" alt="logo">      
  <nav>
    <ul class="nav__links">
      <li><a  href="Home.html" >Home </a></li>
      <li><a  href="Discover.php" >Discover </a></li>
      <li><a  href="Login.html" >Log in </a></li>
      <li><a  href="view.php" >View</a></li>

      <li><a  href="Aboutus.html" >About us </a></li>
      <li><a  href="userslist.php" >Users List  </a></li>

  
  
    </ul>
  </nav>  
         <a class"cta" href="mailto:ekhobrani@sm.imamu.edu.sa"><button style="  order: 2;">Contact</button></a>
  
  
   </header>

<body>
    <center>
    <div class="b">
    <h1 style="color: black;">Add journey</h1>
    <button style="margin: 20px;"> <a href="Discover.html"> ADD</button>

</div>



</script>
<?php
    if (isset($_GET["msg"])) {
      $msg = $_GET["msg"];
      echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
      ' . $msg . '
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
    ?>

<table>
<tr>
    <th>User id</th>
    <th>User name & visited place</th>
  
    

</tr>
<?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $rows['id'];?></td>
                <td><?php echo $rows['nametex'];?></td>
                <td><?php echo $rows['image_url'];?></td>
       
                
              </td>
            <?php
                }
            ?>
         


  </tr>
    </table>
    </center>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

</body>
</html><