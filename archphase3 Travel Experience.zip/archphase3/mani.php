</p>
<?php
include('expconn.php');

if(isset($_REQUEST['actionfunction']) && $_REQUEST['actionfunction']!=''){
$actionfunction = $_REQUEST['actionfunction'];

 call_user_func($actionfunction,$_REQUEST,$con);
}
function saveData($data,$con){


 $nametex = $con->real_escape_string($data['nametex']);
 
 $image_url = $con->real_escape_string($data['image_url']);
 $sql = "insert into images('nametex','image_url') values('$nametex','$image_url')";
 if($con->query($sql)){
 showData($data,$con);
 }
 else{
 echo "error";
 }

}
function showData($data,$con){
 $sql = "select * from images order by id asc";
 $data = $con->query($sql);
 $str='<tr class="head"><td>nametex</td><td>im</td><td>image_url</td>';
 if($data->num_rows>0){
 while( $row = $data->fetch_array(MYSQLI_ASSOC)){
 $str.="<tr id='".$row['id']."'><td>".$row['nametex']."</td><td>".$row['image_url']."</td><td>"."</td><td><input type='button' class='ajaxedit' value='Edit'/> <input type='button' class='ajaxdelete' value='Delete'></td></tr>";
 }
 }else{
 $str .= "<td colspan='5'>No Data Available</td>";
 }

echo $str;
}
function updateData($data,$con){
 $nametex = $con->real_escape_string($data['nametex']);
 
 $image_url = $con->real_escape_string($data['image_url']);

 $sql = "update images set nametex='$nametex',image_url='$image_url'";
 if($con->query($sql)){
 showData($data,$con);
 }
 else{
 echo "error";
 }
 }
 function deleteData($data,$con){
 $delid = $con->real_escape_string($data['deleteid']);
 $sql = "delete from images where id=$delid";
 if($con->query($sql)){
 showData($data,$con);
 }
 else{
 echo "error";
 }
 }
?>
<p style="text-align: justify;">